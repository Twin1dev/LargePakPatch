#pragma once
#include <Windows.h>
#include <string>
#include <vector>
#include <cstdio>
#pragma comment(lib,"minhook/minhook.lib")
#include "minhook/MinHook.h"

// Uncomment out once added SDK!
//#include "SDK/SDK.hpp"
//using namespace SDK;