#pragma once

namespace Hooks {
	static void Init()
	{

	}
}
